from tkinter import*
from math import*  #only if you need sqrt, pi, sin, cos or tan
from time import*
from random import*

root = Tk()
screen = Canvas(root, width=1000, height=800, background="black")
screen.pack()

def setInitialValues():
    global xplayer1car, yplayer1car, xplayer2car, yplayer2car
    global player1xspeed, player1yspeed, player2xspeed, player2yspeed
    global player1cardrawing, player2cardrawing, car1GIF, car2GIF
    global timer, steeringwheel1GIF, steeringwheel2GIF
    global Wpressed, Apressed, Spressed, Dpressed, Uppressed, Leftpressed, Rightpressed, Downpressed 

    xplayer1car = 0
    yplayer1car = 0 
    xplayer2car = 10
    yplayer2car = 10
    player1xspeed = 0
    player1yspeed = 0
    player2xspeed = 0
    player2yspeed = 0
    player1cardrawing = 0
    player2cardrawing = 0
    timer = 0
    steeringwheel1GIF = 0
    steeringwheel2GIF = 0
    car1GIF = PhotoImage(file = "car1.gif")
    car2GIF = PhotoImage(file = "car1.gif")

def drawObjects():
    global player1cardrawing, player2cardrawing 
    player1cardrawing = screen.create_image( xplayer1car, yplayer1car,image = car1GIF)
    player2cardrawing = screen.create_image( xplayer2car, yplayer2car,image = car2GIF)

def updateObjects():
    global xplayer1car, yplayer1car, xplayer2car, yplayer2car
						        
    xplayer1car = xplayer1car + player1xspeed
    yplayer1car = yplayer1car + player1yspeed
    xplayer2car = xplayer2car + player2xspeed
    yplayer2car = yplayer2car + player2yspeed

def keyDownHandler( event ):
    global player1xspeed, player1yspeed, player2xspeed, player2yspeed

    if event.keysym == "Left":
        player1xspeed = player1xspeed - 10

    elif event.keysym == "Up":
        player1yspeed = player1yspeed - 10
	
    elif event.keysym == "Right":
        player1xspeed = player1xspeed + 10
	
    elif event.keysym == "Down":
        player1yspeed = player1yspeed + 10
    

def runGame():  
    setInitialValues()

    while True:   #Repeats 100’s of times per second, whether the player is doing anything or not
        drawObjects()  #This should draw only the current fram

        screen.update()
        sleep(0.03)
        screen.delete( player1cardrawing, player2cardrawing )

        updateObjects()  #This should adjust all the objects' positions and speeds


root.after( 0, runGame )


screen.bind( "<Key>", keyDownHandler )


screen.pack()
screen.focus_set()
root.mainloop()
